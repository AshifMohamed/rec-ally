<?php
$baseURL = LINKEDIN_BASE_URL;
$callbackURL = LINKEDIN_CALLBACK_URL;
$linkedinApiKey = LINKEDIN_API_KEY;
$linkedinApiSecret = LINKEDIN_API_SECRET;
$linkedinScope = LINKEDIN_SCOPE;
?>