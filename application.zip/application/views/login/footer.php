    <!-- Scripts -->
    <script src="<?php echo base_url(); ?>assets/js/app.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/script.js" defer="defer"></script>
  </body>

<!-- Mirrored from thetheme.io/thejobs/user-forget-pass.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 23 Dec 2017 17:04:00 GMT -->
</html>