<script type="text/javascript">
    var base_url = '<?=base_url()?>';
</script>

<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from thetheme.io/thejobs/user-forget-pass.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 23 Dec 2017 17:04:00 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Post a job position or create your online resume by TheJobs!">
    <meta name="keywords" content="">

    <title><?php echo $title_header; ?></title>

    <!-- Styles -->
    <link href="<?php echo base_url(); ?>assets/css/app.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/custom.css" rel="stylesheet">

    <!-- Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Oswald:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="../apple-touch-icon.html">
    <link rel="icon" href="<?php echo base_url(); ?>assets/img/favicon.ico">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.14.0/jquery.validate.min.js"></script>
    
  </head>