<div class="col-md-6 col-sm-6 left-padding">
<form id="form_change_email" action="javascript:0">
  <div class="form-group">
    <label for="old_email" class="control-label"> Current Email</label>
    <div class="input-icon right">
      <input
        name="old_email"
        id="old_email"
        placeholder=""
        class="form-control"
        type="email"
        value=""
        required
      />
    </div>
  </div>

  <div style="clear:both;"></div>

  <div class="form-group">
    <label for="new_email" class="control-label"> New Email</label>
    <div class="input-icon right">
      <input
        name="new_email"
        id="new_email"
        placeholder=""
        class="form-control"
        type="email"
        required
      />
    </div>
  </div>

  <div style="clear:both;"></div>

  <div class="form-group pull-right">
    <label class="control-label col-md-2 col-sm-2 col-xs-12"></label>
    <button type="submit" class="btn btn-info" id="btn_change_email" name="btn_change_email">
      Change Email
    </button>
  </div>
</form>
</div>


