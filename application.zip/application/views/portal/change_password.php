<div class="col-md-6 col-sm-6 left-padding">
<form id="form_change_pwd" action="javascript:0">
  <div class="form-group">
    <label for="old_password" class="control-label"> Current Password</label>
    <div class="input-icon right">
      <input
        name="old_password"
        id="old_password"
        placeholder=""
        class="form-control"
        type="password"
        required
      />
    </div>
  </div>

  <div style="clear:both;"></div>

  <div class="form-group">
    <label for="new_password" class="control-label"> New Password</label>
    <div class="input-icon right">
      <input
        name="new_password"
        id="new_password"
        placeholder=""
        class="form-control"
        type="password"
        required
      />
    </div>
  </div>

  <div style="clear:both;"></div>

  <div class="form-group">
    <label for="confirm_password" class="control-label"> Confirm Password</label>
    <div class="input-icon right">
      <input
        name="confirm_password"
        id="confirm_password"
        placeholder=""
        class="form-control"
        type="password"
        required
      />
    </div>
  </div>

  <div style="clear:both;"></div>

  <div class="form-group pull-right">
    <label class="control-label col-md-2 col-sm-2 col-xs-12"></label>
    <button type="submit" class="btn btn-info" id="btn_change_pwd" name="btn_change_pwd">
      Change Password
    </button>
  </div>
  </form>
</div>
