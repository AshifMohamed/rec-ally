<?php $this->load->view('partial/portal_header.php'); ?>
<?php $this->load->view('partial/portal_sidebar.php'); ?>
<?php $this->load->view('partial/portal_breadcrumbs.php'); ?>
<!--BEGIN CONTENT-->
                <div class="page-content">
                    <div id="tab-general">
                        <div class="row mbl">
                            <div class="col-lg-12 block-space">
                                <div class="panel">
                                    <div class="panel-body">
                                        <div class="row">
                                           <div class="col-md-12 col-sm-12">
                                                <div class="col-md-8 col-sm-8 left-padding">
                                                    <h5>1.Are you ccna certified</h5>
                                                </div>                                                  
                                                <div class="edit-delete text-right pull-right">
                                                    <ul>
                                                        <li>
                                                            <button class="edit-btn" type="submit"><i class="fa fa-pencil-square-o"></i> Edit</button>
                                                        </li>
                                                        <li>
                                                            <button class="dlt-btn" type="submit"><i class="fa fa-trash-o"></i> Delete</button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>                                                      
                                        </div>
                                            <div style="clear:both;"></div>
                                                <div class="bottom-slider">
                                                    <div class="col-md-8 col-sm-8 left-padding">
                                                        <div class="form-group">
                                                            <div class="input-icon right">
                                                                <textarea id="inputSubject" type="text" placeholder="" class="form-control"></textarea></div>
                                                        </div>
                                                        <div style="clear:both;"></div>
                                                    </div>
                                                    <div class="form-group pull-right">
                                                            <label class="control-label col-md-2 col-sm-2 col-xs-12"></label>
                                                            <button class="info-save btn-info btn">Save</button>
                                                    </div>
                                                    <div style="clear:both;"></div>
                                                </div>
                                    </div>
                                </div>
                                <div class="panel">
                                    <div class="panel-body">
                                        <div class="row">
                                           <div class="col-md-12 col-sm-12">
                                                <div class="col-md-8 col-sm-8 left-padding">
                                                    <h5>1.Are you member in Jordan Engineering Association?</h5>
                                                </div>                                                  
                                                <div class="edit-delete text-right pull-right">
                                                    <ul>
                                                        <li>
                                                            <button class="edit-btn" type="submit"><i class="fa fa-pencil-square-o"></i> Edit</button>
                                                        </li>
                                                        <li>
                                                            <button class="dlt-btn" type="submit"><i class="fa fa-trash-o"></i> Delete</button>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>                                                      
                                        </div>
                                            <div style="clear:both;"></div>
                                                <div class="bottom-slider">
                                                    <div class="col-md-8 col-sm-8 left-padding">
                                                        <div class="form-group">
                                                            <div class="input-icon right">
                                                                <textarea id="inputSubject" type="text" placeholder="" class="form-control"></textarea></div>
                                                        </div>
                                                        <div style="clear:both;"></div>
                                                    </div>
                                                    <div class="form-group pull-right">
                                                            <label class="control-label col-md-2 col-sm-2 col-xs-12"></label>
                                                            <button class="info-save btn btn-info">Save</button>
                                                    </div>
                                                    <div style="clear:both;"></div>
                                                </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                <!--END CONTENT-->
<?php $this->load->view('partial/portal_footer.php'); ?>