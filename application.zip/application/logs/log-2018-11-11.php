<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-11-11 05:25:11 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:11 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:25:11 --> Total execution time: 0.1362
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:12 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:13 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:13 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:25:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:25:13 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:20 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:20 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:26:20 --> Total execution time: 0.1490
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:21 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:35 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:26:35 --> Total execution time: 0.1358
DEBUG - 2018-11-11 05:26:35 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:35 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:26:36 --> Total execution time: 0.1745
DEBUG - 2018-11-11 05:26:36 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:36 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:36 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:26:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:36 --> 404 Page Not Found: Uploads/company_logos
ERROR - 2018-11-11 05:26:36 --> 404 Page Not Found: Uploads/company_logos
ERROR - 2018-11-11 05:26:36 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:37 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:37 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:37 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:37 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:26:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:26:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:26:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:26:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:37 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:37 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:28:37 --> Total execution time: 0.1230
DEBUG - 2018-11-11 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:38 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:39 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:39 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:28:39 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:39 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:39 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:39 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:28:39 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:28:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:28:39 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:04 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:29:04 --> Total execution time: 0.1389
DEBUG - 2018-11-11 05:29:04 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:04 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:29:04 --> Total execution time: 0.1469
DEBUG - 2018-11-11 05:29:05 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:05 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:05 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:05 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:29:06 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:38 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:30:39 --> Total execution time: 0.1488
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:40 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:40 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:30:41 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:41 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:41 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:41 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:30:41 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:30:41 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:25 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:27 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:33:27 --> Total execution time: 0.1755
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Uploads/company_logos
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:28 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:29 --> 404 Page Not Found: Uploads/company_logos
ERROR - 2018-11-11 05:33:29 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:33:29 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:28 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:35:29 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:29 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:35:30 --> Total execution time: 0.1853
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:31 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:32 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:32 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:32 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:52 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:35:53 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:53 --> No URI present. Default controller set.
DEBUG - 2018-11-11 05:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:35:54 --> Total execution time: 0.1691
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Uploads/company_logos
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:55 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:55 --> 404 Page Not Found: Assets/front
DEBUG - 2018-11-11 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:56 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:56 --> 404 Page Not Found: Uploads/company_logos
DEBUG - 2018-11-11 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2018-11-11 05:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2018-11-11 05:35:56 --> 404 Page Not Found: Uploads/company_logos
